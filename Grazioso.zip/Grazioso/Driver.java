import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Driver {
	// Creating Dog and Monkey Arraylists. 
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();
    

    public static void main(String[] args) {
    	
        initializeDogList();
        initializeMonkeyList();

        boolean acceptedInput = true;
        Scanner scanner = new Scanner(System.in);
        do {
        	// Displaying the menu first
        	displayMenu();
        	
        	//trimming and converting to lowercase the user input case 
        	String choice = scanner.nextLine().trim().toLowerCase();
        	switch(choice) {
        	
        	case "1":
        		// Input a new dog
        		intakeNewDog(scanner);
        		break;
        		
        	case "2":
        		// Input a new monkey
        		intakeNewMonkey(scanner);
        		break;
        		
        	case "3":
        		// Reserve an animal
        		reserveAnimal(scanner);
        		break;
        		
        	case "4":
        		// print all of the dogs
        		printAnimals("dog");
        		break;
        		
        	case "5":
        		// print all of the monkeys
        		printAnimals("monkey");
        		break;
        		
        	case "6":
        		// Print all non-reserved animals
        		printAnimals("available");
        		break;
        		
        	case "q":
        		acceptedInput = false;
        		break;
        		
        	default:
        		System.out.println("Invalid Menu selection. Try again");
        		break;
        	}
        	
        } while(acceptedInput);
        
        System.out.println("You are Exiting the Application..... Have a Great Day! Thank you.");
        		
    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "in service", true, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", false, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }

    public static void initializeMonkeyList() {
    	Monkey monkey1 = new Monkey("Max", "Capuchin", "male", "2", "5", 6.7, 4.5, 6.7,"06-26-2022", "Unites states", "in service", false, "Canada");
    	Monkey monkey2 = new Monkey("Liam", "Guenon", "female", "6", "7", 6.1, 6.2, 3.6,"07-01-2019", "Mexico", "Phase II", true, "United States");
    	Monkey monkey3 = new Monkey("Curie", "Tamarin", "female", "5", "9", 6.7, 4.5, 7.2,"09-13-2020", "Costa Rica", "in service", false, "Brazil");
    	
    	
    	
    	monkeyList.add(monkey1);
    	monkeyList.add(monkey2);
    	monkeyList.add(monkey3);
    }

    public static void intakeNewDog(Scanner scanner) {
    	// Input validating if the dog is already in our system.
	        System.out.println("What is the dog's name?");
	        String name = scanner.nextLine().trim();
    		
	     // going through the dog list to check if the name exist in our system.
	        for(Dog dog: dogList) 
	            if(dog.getName().equalsIgnoreCase(name)) {
	                System.out.println("\n\nThis dog is already in our system\n\n");
	                return; //returns to menu
	            }
	        // Gathering the dog information from the user and assigning it to the variables.
	        System.out.println("What is " + name + "'s breed?");
	        String breed = scanner.nextLine().trim();
	    
		    System.out.println("What is " + name + "'s gender? (\"male\", \"female\")");
		    String gender = scanner.nextLine().trim().toLowerCase();
	    
		    System.out.println("What is " + name + "'s age?");
		    String age = scanner.nextLine().trim();
		    
		    System.out.println("What is " + name + "'s weight? (in pounds)");
		    String weight = scanner.nextLine().trim();
		    
		    System.out.println("When was " + name + "'s acquired? (MM-DD-YYYY)");
		    String acquisitionDate = scanner.nextLine().trim();
		    
		    System.out.println("Where was " + name + "'s acquired? (Country)");
		    String acquisitionCountry = scanner.nextLine().trim();
		    
		    System.out.println("What is " + name + "'s training status?(\"intake\", \"in service\", \"Phase I/II/III\")");
		    String trainingStatus = scanner.nextLine().trim();
		    
		    System.out.println("Is " + name + "'s reserved? (Y/N)");
		    boolean reserved = scanner.nextLine().trim().equalsIgnoreCase("Y");
		    
		    System.out.println("What is " + name + "'s service country?");
		    String inServiceCountry = scanner.nextLine().trim();
	       


	        
	    // acquiring the new dog's details from the user and assigning it to the new dog with contructor.
	    Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
	    // adding the new dog to the arraylist
	    dogList.add(newDog);
	    System.out.println(name + " has been added to our System. Thank you.");
    	

    }


     public static void intakeNewMonkey(Scanner scanner) {
    	 // Input validating if the monkey is already in our system
    	 System.out.println("what is the monkey's name?");
    	 String name = scanner.nextLine().trim();
    	 
    	 // going through the monkey list to check if the name exist in our system.
    	 for (Monkey monkey : monkeyList)
    		 if (monkey.getName().equalsIgnoreCase(name)) {
    			 System.out.println("\n\nThis monkey is already in our system\n\n");
    			 return;
    		 }
    	 
    	 // Input Validating for the eligible species
    	 boolean ineligibleSpecies = true;
    	 String species;
    	 
    	 do {
    		 System.out.println("what is " + name + "'s species?");
    		 System.out.println("Eligible species are Capuchin, Guenon, Macaque, Marmoset, Squirrel monkey, Tamarin");
    		 species = scanner.nextLine().trim();
    		 
			 for (String eligibleSpecies : Monkey.ELIGIBLE_SPECIES)
				 if (species.equalsIgnoreCase(eligibleSpecies)) 
					 ineligibleSpecies = false;
			 
			 	 if (ineligibleSpecies)
				    System.out.println("Ineligible species selected");
    	 } while (ineligibleSpecies);
    	
         // Gathering the monkey information from the user and assigning it to the variables.
     
 	    System.out.println("What is " + name + "'s gender? (\"male\", \"female\")");
 	    String gender = scanner.nextLine().trim().toLowerCase();
     
 	    System.out.println("What is " + name + "'s age?");
 	    String age = scanner.nextLine().trim();
 	    
 	    System.out.println("What is " + name + "'s weight? (in pounds)");
 	    String weight = scanner.nextLine().trim();
 	    
 	    System.out.println("What is " + name + "'s tail's length? (in centimeters)");
 	    double tailLength = scanner.nextDouble();
 	    
 	    System.out.println("What is " + name + "'s height? (in centimeters)");
 	    double height = scanner.nextDouble();
 	    
 	    System.out.println("What is " + name + "'s body's length? (in inches)");
 	    double bodyLength = scanner.nextDouble();
 	    scanner.nextLine();

	    System.out.println("When was " + name + "'s acquired? (MM-DD-YYYY)");
	    String acquisitionDate = scanner.nextLine().trim();
	    
	    System.out.println("Where was " + name + "'s acquired? (Country)");
	    String acquisitionCountry = scanner.nextLine().trim();
 	    
 	    System.out.println("What is " + name + "'s training status?(\"intake\", \"in service\", \"Phase I/II/III\")");
 	    String trainingStatus = scanner.nextLine().trim();
 	    
 	    System.out.println("Is " + name + "'s reserved? (Y/N)");
 	    boolean reserved = scanner.nextLine().trim().equalsIgnoreCase("Y");
 	    
 	    System.out.println("What is " + name + "'s service country?");
 	    String inServiceCountry = scanner.nextLine().trim();
 	    

 	    
 	    // acquiring the new dog's details from the user and assigning it to the new dog with constructor.
 	    Monkey newMonkey = new Monkey(name, species, gender, age, weight, tailLength, height, bodyLength, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
 	   
 	    // adding the new dog to the arraylist
 	    monkeyList.add(newMonkey);
 	    System.out.println(name + " has been added to our System. Thank you.");
}

     	// Reserves an animal by type and country
        public static void reserveAnimal(Scanner scanner) {
        	System.out.println("What type of animal will be needed? (\"dog\", \"monkey\")");
        	String animalType = scanner.nextLine().trim();
        	
        	System.out.println("Where will the animal be serving? (Country)");
        	String animalServiceCountry = scanner.nextLine().trim();
        	
        	// going through all the dogs in the dog list to check the non-reserved dogs
        	// Reserves the first non-reserved, and in-service dogs in the country
        	if(animalType.equalsIgnoreCase("dog")) { 
        		for (Dog dog : dogList) {
        			if (true && dog.getInServiceLocation().equalsIgnoreCase(animalServiceCountry) && !dog.getReserved()) {
        				dog.setReserved(true);
        				dog.setInServiceCountry(animalServiceCountry);
        				System.out.println(dog.getName() + " has been reserved for you in " + animalServiceCountry + ", Thank you.");
        				return;
        			}
        		}
        	}
        	
            
        	// going through all the monkeys in the monkey list to check the non-reserved monkeys
            // Reserves the first non-reserved, and in-service monkeys in the country
            if(animalType.equalsIgnoreCase("monkey")) {
            	for (Monkey monkey : monkeyList) {
            		if (true && monkey.getInServiceLocation().equalsIgnoreCase(animalServiceCountry) && !monkey.getReserved()) {
            			monkey.setReserved(true);
            			monkey.setInServiceCountry(animalServiceCountry);
            			System.out.println(monkey.getName() + " has been reserved for you in " + animalServiceCountry + ", Thank you.");
            			return;
            		}
            	}
            }
            		
            	
            
     
        
        System.out.println("There isn't any " + animalType + " available in " + animalServiceCountry + " at this time");

        }

        // prints the list of different types of animals and all animals
        // prints the name, status, acquisition country, and reserved status of the animals
        public static void printAnimals(String choiceType) {
            System.out.printf("%-15s| %-15s| %-20s| %s%n%n", "Name", "Status", "Acquisition Country", "Reserved");
            switch(choiceType) {
            // prints all the dog list
            case "dog":
            	for(Dog dog : dogList) {
            		String name = dog.getName();
            		String status = dog.getTrainingStatus();
            		String acquistionCountry = dog.getAcquisitionLocation();
            		boolean reserved = dog.getReserved();
            		System.out.printf("%-15s| %-15s| %-20s| %s%n", name, status, acquistionCountry, reserved);
            	}
            	break;
         
            case "monkey":
            	// prints all the monkey list
                for(Monkey monkey : monkeyList) {
                	String name = monkey.getName();
                	String status = monkey.getTrainingStatus();
                	String acquistionCountry = monkey.getAcquisitionLocation();
                	boolean reserved = monkey.getReserved();
                	System.out.printf("%-15s| %-15s| %-20s| %s%n", name, status, acquistionCountry, reserved);
                }
                break;
                
            case "available":
            	
            	// prints all the available non-reserved and in service dogs 
            	// iterating through the dog list to check the non-reserved and in service dogs
            	for(Dog dog : dogList) {
            		String name = dog.getName();
            		String status = dog.getTrainingStatus();
            		String acquisitionCountry = dog.getAcquisitionLocation();
            		boolean reserved = dog.getReserved();
            		
            		boolean available = !reserved && status.equalsIgnoreCase("in service");
            		
            		if(!available) 
            			continue;
            		
            		System.out.printf("%-15s| %-15s| %-20s| %s%n", name, status, acquisitionCountry, reserved);
            		
            	}
            	
            	// prints all the available non-reserved and in service monkeys 
            	// iterating through the monkey list to check the non-reserved and in service monkeys
            	for(Monkey monkey : monkeyList) {
            		String name = monkey.getName();
            		String status = monkey.getTrainingStatus();
            		String acquisitionCountry = monkey.getAcquisitionLocation();
            		boolean reserved = monkey.getReserved();
            		
            		boolean available = !reserved && status.equalsIgnoreCase("in service");
            		
            		if(!available) 
            			continue;
            		
            		System.out.printf("%-15s| %-15s| %-20s| %s%n", name, status, acquisitionCountry, reserved);
            		
            	}
            	break;
            }
        }
}



















