
public class Monkey extends RescueAnimal {
	private String species;
	private double tailLength;
	private double height;
	private double bodyLength;
	
	// creating the list of eligible monkey species for training
	public final static String[] ELIGIBLE_SPECIES = {
			"Capuchin",
			"Guenon",
			"Macaque",
			"Marmoset",
			"Squirrel monkey",
			"Tamarin"
	};
	
    // Constructor
    public Monkey (String name, String species, String gender, String age,
    String weight, double tailLength, double height, double bodyLength, String acquisitionDate, String acquisitionCountry,
	String trainingStatus, boolean reserved, String inServiceCountry) {
    	 
       	setName(name);
    	setSpecies(species);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setTailLength(tailLength);
        setHeight(height);
        setBodyLength(bodyLength);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
    }
    
    public String getSpecies () {
    	return species;
    }
    
    public void setSpecies (String monkeySpecies) {
    	species = monkeySpecies;
    }
    
    public double getTailLength () {
    	return tailLength;
    }
    
    public void setTailLength (double monkeyTailLength) {
    	tailLength = monkeyTailLength;
    }
    
    public double getHeight () {
    	return height;
    }
    
    public void setHeight(double monkeyHeight) {
    	height = monkeyHeight;
    }
    
    public double getBodyLength () {
    	return bodyLength;
    }
    
    public void setBodyLength (double monkeyBodyLength) {
    	bodyLength = monkeyBodyLength;
    }
    
}
